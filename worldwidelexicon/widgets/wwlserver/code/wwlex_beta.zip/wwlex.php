<?php
/*
Plugin Name: Worldwide Lexicon Translator
Plugin URI: http://worldwidelexicon.org/
Description: Add community-powered, professional or automatic transaltions to your WordPress blog.
Version: 0.1
Author: Worldwide Lexicon Inc
Author URI: http://www.worldwidelexicon.org/
*/
// Pre-2.6 compatibility
if ( ! defined( 'WP_CONTENT_URL' ) )
      define( 'WP_CONTENT_URL', get_option( 'siteurl' ) . '/wp-content' );
if ( ! defined( 'WP_CONTENT_DIR' ) )
      define( 'WP_CONTENT_DIR', ABSPATH . 'wp-content' );
if ( ! defined( 'WP_PLUGIN_URL' ) )
      define( 'WP_PLUGIN_URL', WP_CONTENT_URL. '/plugins' );
if ( ! defined( 'WP_PLUGIN_DIR' ) )
      define( 'WP_PLUGIN_DIR', WP_CONTENT_DIR . '/plugins' );
      
require(WP_PLUGIN_DIR."/wwlex/services_json.class.php");     
require(WP_PLUGIN_DIR."/wwlex/filecache.class.php");      
require(WP_PLUGIN_DIR."/wwlex/wwl.php");
require(WP_PLUGIN_DIR."/wwlex/wwlex.class.php");

$wwlex = new wwlex(WP_PLUGIN_DIR);
if (get_option('wwl_translation_timeout')) {
	$wwlex->timeout = get_option('wwl_translation_timeout');
}
if (get_option('wwl_cache_timeout')) {
	$wwlex->setCacheExpire(get_option('wwl_cache_timeout'));
}

function wwl_init() {
	global $wwlex;

	add_action('admin_menu', 'wwl_config_page');

}
function wwl_inject_script() {
	wp_print_scripts( array( 'sack' ));
	echo '<!--wwl script--><script src="'.WP_PLUGIN_URL.'/wwlex/wwlex.js" type="text/javascript"></script>';
	echo '<!--wwl css--><link rel="stylesheet" href="'.WP_PLUGIN_URL.'/wwlex/wwlex.css" type="text/css" media="screen" />';
}
function wwl_footer() {
	global $wwlex;
	echo '<script type="text/javascript">';
	echo 'wwl.chunks = '.$wwlex->chunksJSON().';';
	echo 'wwl.sourceLanguageName = "'.$wwlex->sourceLanguageName().'";';
	echo 'wwl.targetLanguageName = "'.$wwlex->targetLanguageName().'";';
	echo 'wwl.targetLanguage = "'.$wwlex->targetLanguage.'";';
	echo 'wwl.ajaxurl = "'.get_option('siteurl').'/wp-admin/admin-ajax.php";';
	echo '</script>';
	echo '<div id="wwl-inline-editor" class="wwl-hide">';
	echo '	<div id="wwl-inline-editor-title">Edit translation</div>';
	echo '	<div id="wwl-inline-editor-original"></div>';
	echo '	<textarea id="wwl-inline-editor-translated"></textarea>';
	echo '	<input id="wwl-inline-editor-update" type="button" value="Update translation" onclick="return wwl.submitTranslation();"/>';
	echo '	or <a href="#" onclick="return wwl.hideTranslatorWindow();">Cancel</a>';
	echo '</div>';
}
function wwl_config_page() {
	add_options_page(__('Worldwide Lexicon Options'), __('Worldwide Lexicon'), 'administrator', 'wwlex-options', 'wwl_options');
}

function wwl_options() {
	global $wwlex;
	require(WP_PLUGIN_DIR."/wwlex/wwlex.options.php");
}

function wwl_clear_cache() {
	global $wwlex;
	$wwlex->clearCache();
}

function wwl_update_translation() {
	global $wwlex;
	$out = array();
	$out["chunkId"] = $_POST["chunkId"]; // echo back
	$out["result"] = $wwlex->updateTranslation($_POST["source"], $_POST["text"]);
	$out["translated"] = $wwlex->moveTags($_POST["sourceWithTags"], $_POST["text"]);
	//print_r($out);
	die(str_replace("\\\\", "\\", $wwlex->jsonEncode($out)));
}

function wwl_sidebar_widget($args) {
	extract($args);
	global $wwlex;
	require(WP_PLUGIN_DIR."/wwlex/wwlex.widget.php");
}
// title doesn't need splitting into chunks
function wwl_translate_title($str) {
	global $wwlex, $id, $post;
	//print_r($post);die;
	if ($post->post_title == $str) {
		$idt = "wwl-title-".$id;
		return 	'<span id="'.$idt.'">'.$wwlex->translateSentence($str).'</span>'.
				'<span id="'.$idt.'_tr" class="wwl-hide">'.$str.'</span>';
	} else {
		return $str;
	}
}
function wwl_translate_content($str) {
	global $wwlex, $id;
	$idt = "wwl-title-".$id;
	$idw = "wwl-content-".$id;
	$out = "<span id=\"".$idw."\"><blockquote class=\"wwl-decorations\">(".$wwlex->sourceLanguageName()." &rarr; ".$wwlex->targetLanguageName().") ";
	$out.= "<a href\"#\" onclick=\"wwl.swap('".$id."_tr', '".$id."'); return false;\">View original</a>";
	if ($wwlex->canTranslate()) {
		$out.= ' [<a href="#" onclick="return wwl.edit(\''.$id.'\');">Edit</a>]';
	}
	$out.= "</blockquote>";
	$out.= $wwlex->translateContent($str)."</span>";
	$out.= "<span id=\"".$idw."_tr\" class=\"wwl-decorations wwl-hide\">";
	$out.= "<blockquote>(original) ";
	$out.= "<a href\"#\" onclick=\"wwl.swap('".$id."', '".$id."_tr'); return false;\">View ".$wwlex->targetLanguageName()." translation</a></blockquote>";
	$out.= $str."</span>";
	return $out;
	//return $wwlex->translateContent($str);
}

add_action('init', 'wwl_init');
add_action('wp_head', 'wwl_inject_script');
add_action('wp_footer', 'wwl_footer');
add_action('wp_ajax_wwl_clear_cache', 'wwl_clear_cache');
add_action('wp_ajax_wwl_update_translation', 'wwl_update_translation');
add_action('wp_ajax_nopriv_wwl_update_translation', 'wwl_update_translation');

register_sidebar_widget('Worldwide Lexicon Widget', 'wwl_sidebar_widget');

// don't add the filter unless we need it
if ($wwlex->needTranslation) {
	add_filter('the_title','wwl_translate_title');
	add_filter('the_content','wwl_translate_content');
}
?>