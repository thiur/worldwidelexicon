<?php
/**
 *  WWLphp: a simple PHP wrapper library for the World Wide Lexicon 
 *  This library enables PHP based applications to easily interact with the servers of the World Wide Lexicon.
 *
 *	@package		wwlphp
 *  @author 		Cesar Gonzalez (icesar@gmail.com)
 *  @version 		1.0
 *  @license		BSD
 *
 *
 *	NOTES:
 *	============
 *	+ Make sure to set this at the top of any scripts using WWLphp.
 *		mb_internal_encoding('UTF-8');
 *		mb_http_output('UTF-8');
 *
 *
 *	STILL TO DO:
 *	============
 *
 */


/**
 *  memcache - If the server has the memcache daemon running and the PHP memcache extension
 *  is enabled, then lets use it.  Enable memcache below and set the address and ttl.
 *
 */
define( 'MEMCACHE_ENABLED', true);

/**
 *	This class encapsulates the functionality of the WWL (the World Wide Lexicon) for automatically
 *	translating content on the web between languages.
 *	@package		wwlphp
 */
class wwl {
	var $targetLanguage = "";
	var $sourceLanguage =  "";
	
	var $wwl_servers = array('www.worldwidelexicon.org');
	var $secure_wwl_servers = array('worldwidelexicon.appspot.com');

	var $memcache_address = 'localhost';
	var $memcache_port = 2020;
	var $memcache_ttl = 86400;		// Time to maintain translation in memcache, in seconds  [24 hours]

	// For gettext() support
	var $gettext_app_domain = "mydomain";
	var $gettext_base_path = "/www/htdocs/myapp.com/locale";
	
	var $cacher = null; // assign an object implementing "get" and "set" methods to use external caching
	
	function __construct($sl = '', $tl = '') {
		$this->targetLanguage = $tl;
		$this->sourceLanguage = $sl;
	}			
		
	function wwl($sl = '', $tl = '') {
		$this->__construct($sl, $tl);		
	}
	
	/**
	 *	Return the gettext() translation of a given string for a given pair of languages.
	 *
	 *  @param string $sl source language ISO code
	 *  @param string $tl target language ISO code
	 *  @param string $st string to be translated
	 */
	function gt( $st ) {
		
		// Make sure all arguments are not empty strings.
		if ( function_exists('gettext') && strlen($this->sourceLanguage) > 0 && strlen($this->targetLanguage) > 0 && strlen($st) > 0 && strlen( $this->gettext_base_path ) > 0 ) {
		
			// Set the environment for gettext() and see if there is a translation there.
			bindtextdomain( $this->gettext_app_domain, $this->gettext_base_path . '/' . $this->targetLanguage );
			textdomain( $this->gettext_app_domain );
			$tt = gettext( $st );
			
			if ( $tt != $st ) {
				
				// If we have a gettext() translation, store it and return it.
				$this->setcache( $st, $tt );
				return $tt;
			}
		}
		return '';
	}


	/**
	 *	Use this to authenticate a username and password pair, or session key.  Returns an MD5
	 *	hash key (session ID) if successful, an empty string if not.
	 *
	 *	@param string $username
	 *	@param string $password
	 *	@param string $session
	 *  @return string MD5 has key or empty string if fail.
	 */
	function auth( $username='', $password='', $session='' ) {
	
		if ( strlen($username) > 0 && strlen($password) > 0 || strlen($session) > 0 ) {
			
			$url = $this->server(true) . "/users/auth";
			$request = array();

			if ( strlen( $session ) > 0 ) {			
				$request['session'] = $session;
			} else {
				$request['username'] = $username;
				$request['pw'] = $password;
			}
			
			$response = $this->sendRequest($url, $request);
			return $reponse;
		} else {
			return '';
		}
	}


	/**
	 *	Create a new user account.  Returns True or False, and if successful, sends a welcome
	 *	email to the user asking to click on a link to validate their account.
	 *
	 *	@param string $username WWL username, required
	 *	@param string $pw WWL password, required
	 *	@param string $email the user's email address, required
	 *	@param string $firstname
	 *	@param string $lastname
	 *	@param string $city
	 *	@param string $state
	 *	@param string $country
	 *	@param string $description
	 *	@return boolean
	 */
	function newuser( $username, $pw, $email, $firstname='', $lastname='', $city='', $state='', $country='', $description='' ) {
	
		// There is a 6 character minimum on the username and  8 characters on the password
		if ( strlen($username) > 5 && strlen($pw) > 7 ) {
			
			// Use the secure server for new user submit
			$url = $this->server(true) . "/users/new";
			
			// Set up the submit
			$request['username'] = $username;
			$request['pw'] = $pw;
			$request['email'] = $email;
			$request['firstname'] = $firstname;
			$request['lastname'] = $lastname;
			$request['city'] = $city;
			$request['state'] = $state;
			$request['country'] = $country;
			$request['description'] = $description;
		
			$response = $this->sendRequest($url, $request);
			return ($response == 'ok');	
		} else {
			// Username or password is too short.
			return false;
		}
	}
	
	
	/**
	 *	Gets a parameter corresponding to a user. Expects the username and param name.
	 *	Returns a string with the stored param value.
	 *
	 *	@param string $username
	 *	@param string $parm
	 *	@return string
	 *
	 */
	function getparm( $username, $parm ) {
		
		$url = $this->server() . "/users/get";
		$request['username'] = $username;
		$request['parm'] = $parm;
		
		$response = $this->sendRequest($url, $request);
		return $response;
	}
	
	
	/**
	 *	Set a parameter for a given user to a given value.
	 *
	 *	@param string $username
	 *	@param string $pw
	 *	@param string $parm
	 *	@param string $value
	 *	@return boolean
	 *
	 */
	function setparm() {
		
		$url = $this->server(true) . "/users/set";
		$request['username'] = $username;
		$request['pw'] = $pw;
		$request['parm'] = $parm;
		$request['value'] = $value;
		
		$response = $this->sendRequest($url, $request);
		return ($response == 'ok');
	}
	
	
	/**
	 *	Returns the WWL server corresponding to $idx, which is secure if the $secure flag is set.
	 *  Both $secure and $idx have defaults, so the function can be called without arguments.
	 *
	 *	@param boolean $secure
	 *	@param integer $idx
	 *  @return string
	 */
	function server ( $secure=false, $idx=0 ) {

		try {
			if ( $secure ) { 
				$url = 'https://' . $this->secure_wwl_servers[$idx]; 
			} else { 
				$url = 'http://' . $this->wwl_servers[$idx]; 
			}

		} catch (Exception $e) {
			$url = '';
		}
		
		return $url;
	}


	/**
	 *  Checks if the requested translation is stored in the local memcache and if so return it, otherwise
	 *	return an empty string.
	 *
	 *  @param string $st string to be translated
	 *  @return string
	 */
	function getcache( $st ) {
		
		// If memcache is enabled, make sure all arguments are not empty strings.
		if ( class_exists("Memcache") && MEMCACHE_ENABLED && strlen($this->memcache_address) > 0 && strlen($this->sourceLanguage) > 0 && 
			strlen($this->targetLanguage) > 0 && strlen($st) > 0 && strlen($tt) > 0 ) {
				
			$memcache = new Memcache;
			if ( $memcache->connect( $this->memcache_address, $this->memcache_port) ) {

				// Check if there is a memcached result, if so return it.
				$result = $memcache->get( MD5($this->sourceLanguage . $this->targetLanguage . $st) );
				return $result;
			}
			
		}
		return '';
	}


	/**
	 *	Add a translated text to the local memcache.  Return true on success false on failure.
	 *
	 *  @param string $st string to be translated
	 *  @param string $tt string holding translation of $st
	 */
	function setcache( $st, $tt ) {

		// If memcache is enabled, also make sure all arguments are not empty strings.
		if (class_exists("Memcache") && MEMCACHE_ENABLED && strlen($this->memcache_address) > 0 && strlen($this->sourceLanguage) > 0 && 
			strlen($this->targetLanguage) > 0 && strlen($st) > 0 && strlen($tt) > 0 ) {
		
			$memcache = new Memcache;
			if ( $memcache->connect( $this->memcache_address, $this->memcache_port) ) {
				if ( $memcache->set( MD5($this->sourceLanguage . $this->targetLanguage . $st), $tt, false, $this->memcache_ttl) ) { 
					return true;
				} 
			}
		}
		return false;
	}
	
	function get_ext_cache ( $st) {
		if (!$st || !$this->cacher || !method_exists($this->cacher, "get")) {
			return "";
		}
		$res = explode("|", $this->cacher->get(md5($this->sourceLanguage . $this->targetLanguage . $st)));
		return $res[0];
	}
	
	function set_ext_cache ( $st, $tt) {
		if (!$st || !$this->cacher || !method_exists($this->cacher, "set")) {
			return false;
		}
		return $this->cacher->set(md5($this->sourceLanguage . $this->targetLanguage . $st), $tt."|".$st."|".$this->sourceLanguage."|".$this->targetLanguage);
	}
	
	/**
	 *	This function is used to get the best available translation from a WWL server.
	 *	
	 *  @param string $sl source language (ISO code)
	 *  @param string $tl target language (ISO code)
	 *  @param string $st string to be translated
	 *  @param string $domain filter results to domain=foo.com
	 *  @param string $allow_machine y/n to allow or hide machine translations
	 *  @param string $allow_anonymous y/n to allow or hide translations from unregistered users
	 *  @param string $require_professional y/n to require professional translations
	 *  @param string $ip_filter limit results to submissions from trusted IP address or pattern
	 *  @param string $lsp language service provider name, if pro translations are desired
	 *  @param string $lspusername username with LSP
	 *  @param string $lsppw password or API key for LSP
	 *  @param string $mtengine force selection of specific machine translation engine (eg. google, apertium, moses, worldlingo)
	 */
	function get($st, $domain='', $allow_machine='y', $allow_anonymous='y', $require_professional='n', 
				  $ip_filter='', $lsp='', $lspusername='', $lsppw='', $mtengine='' ) {
	
		// Make sure vital arguments are not empty strings.
		if ( strlen($this->sourceLanguage) > 0 && strlen($this->targetLanguage) > 0 && strlen($st) > 0 ) {
		
			// First, try to get a cached translation (returns empty if not running)
			$tt = $this->getcache($st);			
			if ( strlen( $tt ) > 0 ) { return $tt; }
			
			$tt = $this->get_ext_cache($st);			
			if ( strlen( $tt ) > 0 ) { return $tt; }
			
			// Next, check if gettext() knows the translation (returns empty if not present)
			$tt = $this->gt($st);
			if ( strlen( $tt ) > 0 ) { return $tt; }
			
			// No on both counts? Then let's request a translation from the WWL server
			$request['sl'] = $this->sourceLanguage;
			$request['tl'] = $this->targetLanguage;
			$request['st'] = $st;
			$request['domain'] = $domain;
			$request['allow_machine'] = $allow_machine;
			$request['allow_anonymous'] = $allow_anonymous;
			$request['require_professional'] = $require_professional;
			$request['ip'] = $ip_filter;
			$request['lsp'] = $lsp;
			$request['lspusername'] = $lspusername;
			$request['lsppw'] = $lsppw;
			$request['mtengine'] = $mtengine;
			$request['output'] = 'text';
			
			// Build the URL for the REST query
			$url = $this->server() . "/t?" . http_build_query($request);
			$response = $this->sendRequest($url, $request);	
			if (strlen( $response ) > 0) {
				$this->setcache($st, $response);
				$this->set_ext_cache($st, $response);
			}
			return $response;
		}
		return ''; 
	}


	/**
	 *  Submit a translation to the WWL server.
	 *
	 *  @param string $sl source language (ISO code)
	 *  @param string $tl target language (ISO code)
	 *  @param string $st string to be translated (UTF-8)
	 *  @param string $tt translation of $st to submit (UTF-8)
	 *  @param string $domain site domain or API key
	 *  @param string $url parent URL of source document (use full permalink)
	 *  @param string $username WWL or remote username
	 *  @param string $pw WWL or remote password
	 *	@return bool
	 */
	function submit($st, $tt, $domain='', $url='', $username='', $pw='' ) {
		
		// Save this translation to the local memcache
		$this->setcache($st, $tt);
		$this->set_ext_cache($st, $tt);
		
		// And now submit the translation to the WWL server
		$request['sl'] = $this->sourceLanguage;
		$request['tl'] = $this->targetLanguage;
		$request['st'] = $st;
		$request['tt'] = $tt;
		$request['domain'] = $domain;
		$request['url'] = $url;
		$request['username'] = $username;
		$request['pw'] = $pw;
		
		// Build the URL for the REST submission
		$url = $this->server() . "/submit";
		$response = $this->sendRequest($url, $request);
		return ($response == 'ok');
	}

	/**
	 *	Score a given translation from the WWL.  Returns true on success false on not success.
	 *
	 *  @param string $sl source language (ISO code)
	 *  @param string $tl target language (ISO code)
	 *  @param string $st string to be translated (UTF-8)
	 *  @param string $tt translation of $st to submit (UTF-8)
	 *	@param string $votetype 
	 *  @param string $username
	 *  @param string $pw
	 *  @param string $proxy
	 *	@return bool
	 */
	function score( $st, $tt, $votetype='', $username='', $pw='', $proxy='n') {

		$guid = MD5( $this->sourceLanguage . $this->targetLanguage . $st . $tt );
		
		// Score a translation and save it to the WWL server
		$request['guid'] = $guid;
		$request['votetype'] = $votetype;
		$request['username'] = $username;
		$request['pw'] = $pw;
		$request['proxy'] = $proxy;
		
		// Build the URL used in submitting this score.  Get the secure server.
		$url = $this->server(true) . '/scores/vote';
		$response = $this->sendRequest($url, $request);
		return ($response == 'ok');		
	}

	function sendRequest($url, $data = array()) {
		if (!function_exists('curl_init')) {
			return '';
		}
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);								
		curl_setopt($curl, CURLOPT_HEADER, false); 	
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		if ($data) {
		 	curl_setopt($curl, CURLOPT_POST, true);									
			curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));		
		}
		// Get the response and close the cURL session.
		$response = curl_exec($curl);
		if (curl_getinfo($curl, CURLINFO_HTTP_CODE) != "200") {
			return '';
		}
		curl_close($curl);
		return $response;
	}

} /* end Class wwl */

